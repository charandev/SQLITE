const LocalStrategy = require("passport-local").Strategy;
const bcrypt = require("bcryptjs");
var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("./database/animals.db");
const { DB_COMMANDS } = require("./global-constants.js");

function initialize(passport, getUserByEmail, getUserById) {
  const authenticateUser = async (email, password, done) => {
    let user = {};
    db.get(DB_COMMANDS.LOGIN.GET_USER_BY_EMAIL, [email], async (err, row) => {
      if (err) {
        res.status(400).json({ error: err.message });
        return;
      }
      user = row;
      if (row == null) {
        return done(null, false, { message: "No user with that email" });
      } else {
        if (await bcrypt.compare(password, row.password)) {
          return done(null, row);
        } else {
          return done(null, false, { message: "Password incorrect" });
        }
      }
    });
  };

  passport.use(new LocalStrategy({ usernameField: "email" }, authenticateUser));
  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser((id, done) => {
    db.get(DB_COMMANDS.LOGIN.GET_USER_BY_ID, [id], (err, row) => {
      return done(null, row);
    });
  });
}

module.exports = initialize;
