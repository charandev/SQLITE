let ANIMAL_DATA = "";
window.onload = function () {
  var id = getParameterByName("id", window.location.href);
  console.log(id, "asdfsadfads");
  getAnimalById(id);
};

function getAnimalById(id) {
  /* AJAX call to get an animal based on its ID */
  var xhttp = new XMLHttpRequest();
  xhttp.open("GET", "http://localhost:3000/api/animals/" + id, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      // Response
      var response = JSON.parse(this.responseText);
      // console.log(response);
      ANIMAL_DATA = response;
      document.getElementById("animal_name").innerHTML = response.animal_name;
      document.getElementById("animal_desc").innerHTML = response.animal_desc;
      let condition;
      if (response.isEndangered == "true" || response.isEndangered == 1) {
        condition = "Yes";
      } else {
        condition = "No";
      }
      document.getElementById("isEndangered").innerHTML = condition;
    }
  };
  xhttp.send();
}

/* Method to truncate #path */
function getParameterByName(name, url = window.location.href) {
  name = name.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
    results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return "";
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}
/* Method to open model for edit animal form*/
function triggerEditAnimalModel(event) {
  event.preventDefault();
  document.getElementById("edit-popup").click();
  console.log(ANIMAL_DATA, "Came here");
  //To populate default values in edit form
  document.getElementById("edit_animal_name").value = ANIMAL_DATA.animal_name;
  document.getElementById("edit_animal_desc").value = ANIMAL_DATA.animal_desc;

  if (ANIMAL_DATA.isEndangered == "true" || ANIMAL_DATA.isEndangered == 1) {
    document.getElementById("yes").checked = true;
  } else {
    document.getElementById("no").checked = true;
  }
 //To remove #route in uri
  var uri = window.location.toString();
  if (uri.indexOf("#") > 0) {
    var clean_uri = uri.substring(0, uri.indexOf("#"));

    window.history.replaceState({}, document.title, clean_uri);
  }

  //   if()
}

function editAnimal(event) {
  var formData = {
    animal_name: "",
    animal_desc: "",
    isEndangered: false,
  };
  formData.animal_name = document.getElementById("edit_animal_name").value;
  formData.animal_desc = document.getElementById("edit_animal_desc").value;
  var ele = document.getElementsByName("edit_isEndangered");

  for (i = 0; i < ele.length; i++) {
    if (ele[i].checked) {
      console.log(ele[i].value, i);
      formData.isEndangered = ele[i].value;
    }
  }

  /* AJAX call to edit any animal */
  var xhr = new XMLHttpRequest();
  xhr.open("PUT", "http://localhost:3000/api/animals/"+ANIMAL_DATA.id, true);

  xhr.setRequestHeader("Content-type", "application/json");

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      console.log(xhr.status);
      console.log(xhr.responseText);
    }
  };

  xhr.send(JSON.stringify(formData));
  window.location.reload()
}
