window.onload = function () {
  getAllAnimals();
};

function getAllAnimals() {
  /* AJAX call to get all animals */
  var xhttp = new XMLHttpRequest();
  xhttp.open("GET", "http://localhost:3000/api/animals/", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      // Response
      var response = JSON.parse(this.responseText);
      appendDomElements(response.rows);
    }
  };
  xhttp.send();
}

function appendDomElements(animals) {
  let container = document.getElementById("animals_card_container");
  for (let index = 0; index < animals.length; index++) {
    let element = animals[index];
    console.log(element);
    var booleanValue;
    if (element.isEndangered == "true" || element.isEndangered == 1) {
      booleanValue = 1;
    } else {
      booleanValue = 0;
    }

    var endangeredColor = booleanValue ? "in-danger" : "not-in-danger";
    var parentDiv = document.createElement("div");
    parentDiv.setAttribute("class", "card " + endangeredColor);
    parentDiv.setAttribute("id", "parent");
    parentDiv.addEventListener("click", function (e) {
      if (e.target) {
        redirectToDescPage(element);
      }
    });
    var deleteBtn = document.createElement("img");
    deleteBtn.setAttribute("class", "delete_btn");
    deleteBtn.setAttribute("id", "delete");
    deleteBtn.setAttribute("src", "images/delete.png");
    deleteBtn.setAttribute("alt", "delete-icon");
    deleteBtn.addEventListener("click", function (e) {
      e.stopPropagation()
      if (e.target && e.target.id == "delete") {
        deleteAnimal(element);
      }
    });
    deleteBtn.setAttribute("title", "Remove Data");

    parentDiv.appendChild(deleteBtn);
    var childDiv = document.createElement("div");
    childDiv.setAttribute("class", "container");

    var h4 = document.createElement("h4");
    var b = document.createElement("b");
    b.innerHTML = element.animal_name;
    h4.appendChild(b);

    var desc = document.createElement("p");
    desc.innerHTML = element.animal_desc;

    childDiv.appendChild(h4);
    childDiv.appendChild(desc);

    parentDiv.appendChild(childDiv);

    container.appendChild(parentDiv);
  }
}
function redirectToDescPage(element) {
  window.location.href = "/animal?id=" + element.id;
}

function deleteAnimal(element) {
  if (confirm("Do you want to delete the " + element.animal_name + " data?")) {

    /* AJAX call to delete an animal */
    var xhttp = new XMLHttpRequest();
    xhttp.open("DELETE", "http://localhost:3000/api/animals/" + element.id);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        // Response
        var response = JSON.parse(this.responseText);
        window.location.reload();
      }
    };
    xhttp.send();
  } else {
  }
}

function triggerAddAnimalModel(event) {
  event.preventDefault();
  document.getElementById("add-popup").click();
  var uri = window.location.toString();
  if (uri.indexOf("#") > 0) {
    var clean_uri = uri.substring(0, uri.indexOf("#"));

    window.history.replaceState({}, document.title, clean_uri);
  }
}
function addAnimal(event) {
  var formData = {
    animal_name: "",
    animal_desc: "",
    isEndangered: false,
  };
  formData.animal_name = document.getElementById("animal_name").value;
  formData.animal_desc = document.getElementById("animal_desc").value;
  var ele = document.getElementsByName("isEndangered");

  for (i = 0; i < ele.length; i++) {
    if (ele[i].checked) {
      console.log(ele[i].value, i);
      formData.isEndangered = ele[i].value;
    }
  }

  /* AJAX call for Adding a new Animal */
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "http://localhost:3000/api/animals/", true);

  xhr.setRequestHeader("Content-type", "application/json");

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      console.log(xhr.status);
      console.log(xhr.responseText);
    }
  };

  xhr.send(JSON.stringify(formData));
  window.location.reload()
}
