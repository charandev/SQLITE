const startButton = document.getElementById('start-btn')
const nextButton = document.getElementById('next-btn')
const questionContainerElement = document.getElementById('question-container')
const questionElement = document.getElementById('question')
const answerButtonsElement = document.getElementById('answer-buttons')

let shuffledQuestions, currentQuestionIndex

startButton.addEventListener('click', startGame)
nextButton.addEventListener('click', () => {
  currentQuestionIndex++
  setNextQuestion()
})

function startGame() {
  startButton.classList.add('hide')
  shuffledQuestions = questions.sort(() => Math.random() - .5)
  currentQuestionIndex = 0
  questionContainerElement.classList.remove('hide')
  setNextQuestion()
}

function setNextQuestion() {
  resetState()
  showQuestion(shuffledQuestions[currentQuestionIndex])
}

function showQuestion(question) {
  questionElement.innerText = question.question
  question.answers.forEach(answer => {
    const button = document.createElement('button')
    button.innerText = answer.text
    button.classList.add('btn')
    if (answer.correct) {
      button.dataset.correct = answer.correct
    }
    button.addEventListener('click', selectAnswer)
    answerButtonsElement.appendChild(button)
  })
}

function resetState() {
  clearStatusClass(document.body)
  nextButton.classList.add('hide')
  while (answerButtonsElement.firstChild) {
    answerButtonsElement.removeChild(answerButtonsElement.firstChild)
  }
}

function selectAnswer(e) {
  const selectedButton = e.target
  const correct = selectedButton.dataset.correct
  setStatusClass(document.body, correct)
  Array.from(answerButtonsElement.children).forEach(button => {
    setStatusClass(button, button.dataset.correct)
  })
  if (shuffledQuestions.length > currentQuestionIndex + 1) {
    nextButton.classList.remove('hide')
  } else {
    startButton.innerText = 'Restart'
    startButton.classList.remove('hide')
  }
}

function setStatusClass(element, correct) {
  clearStatusClass(element)
  if (correct) {
    element.classList.add('correct')
  } else {
    element.classList.add('wrong')
  }
}

function clearStatusClass(element) {
  element.classList.remove('correct')
  element.classList.remove('wrong')
}

const questions = [
  {
    question: 'Which is the largest living bird on Earth?',
    answers: [
        { text: 'Emu', correct: false },
        { text: 'Ostrich', correct: true },
        { text: 'Albatross', correct: false },
        { text: 'Siberian Crane', correct: false }
    ]
  },
  {
    question: 'In which one of the following animals do distinct black stripes extend from the inner corners of the eyes to the mouth?',
    answers: [
      { text: 'Cheetah', correct: true },
      { text: 'Jaguar', correct: false },
      { text: 'Leopard', correct: false },
      { text: 'Panther', correct: false }
    ]
  },
  {
    question: 'For how many years have the dinosaurs been extinct?',
    answers: [
      { text: 'About 25 million years', correct: false },
      { text: 'About 65 milion years', correct: true },
      { text: 'About 100 million years', correct: false },
      { text: 'About 135 million years', correct: false }
    ]
  },
  {
    question: 'Which amongst the following is the largest mammal?',
    answers: [
        { text: 'Elephant', correct: false },        
        { text: 'Dinosaur', correct: false },
        { text: 'Whale', correct: true },
        { text: 'Rhinoceros', correct: false }
    ]
  },
  {
    question: 'This animal fasts for about 8 months in a year and yet is active, gives birth, and nurses its young while fasting. Name the animal.',
    answers: [
        { text: 'Polar Bear', correct: true },        
        { text: 'Frog', correct: false },
        { text: 'Reindeer', correct: false },
        { text: 'Lion', correct: false }
    ]
  },
  {
    question: 'Which one among the following is not an ape?',
    answers: [
        { text: 'Gibbon', correct: false },        
        { text: 'Gorilla', correct: false },
        { text: 'Orangutan', correct: false },
        { text: 'Langur', correct: true }
    ]
  }
]