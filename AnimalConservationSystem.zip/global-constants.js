module.exports = {
  PORT: 3000,
  SECRET_KEY: "SECRETKEY",
  BASE_API_URL: "http://localhost:" + this.PORT + "/api/",
  BASE_URL: "http://localhost:" + this.PORT + "/",
  DB_COMMANDS: {
    GET_ALL: "SELECT * FROM animals",
    CREATE_NEW: "INSERT INTO animals (animal_name, animal_desc, isEndangered) VALUES (?,?,?)",
    GET_BY_ID: "SELECT * FROM animals where id = ?",
    GET_BY_NAME: "SELECT * FROM animals where animal_name = ?",
    UPDATE: "UPDATE animals set animal_name = ?, animal_desc = ?, isEndangered = ? WHERE id = ?",
    DELETE: "DELETE FROM animals WHERE id = ?",
    REGISTER: "INSERT INTO users (username,email, password) VALUES (?,?,?)",
    LOGIN: {
      GET_USER_BY_EMAIL: "SELECT * FROM users where email = ?",
      GET_USER_BY_ID: "SELECT * FROM users where id = ?",
    },
  },
};
