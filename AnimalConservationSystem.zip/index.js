var sqlite3 = require("sqlite3").verbose();
var express = require("express");
var http = require("http");
const bcrypt = require("bcryptjs");
const passport = require("passport");
const flash = require("express-flash");
const session = require("express-session");
const methodOverride = require("method-override");

const initializePassport = require("./passport-config.js");
const { PORT, DB_COMMANDS } = require("./global-constants.js");
var app = express();

// middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
var server = http.createServer(app);
/* Created instance for SQLITE database */
var db = new sqlite3.Database("./database/animals.db");

/* Created a table animals */
db.run(
  "CREATE TABLE IF NOT EXISTS animals( \
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,\
    animal_name NVARCHAR(20)  NOT NULL,\
    animal_desc NVARCHAR(2000)  NOT NULL,\
    isEndangered boolean NOT NULL default 0\
)"
);
/* Created a table users for login functionality */
db.run(
  "CREATE TABLE IF NOT EXISTS users( \
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,\
    username TEXT  NOT NULL,\
    email TEXT  NOT NULL,\
    password TEXT  NOT NULL\
)"
);

server.listen(PORT, function () {
  console.log("server is listening on port: 3000");
});

//Auth

initializePassport(
  passport,
  (email) => users.find((user) => user.email === email),
  (id) => users.find((user) => user.id === id)
);

const users = [];

app.use(express.urlencoded({ extended: false }));

/* Using EJS as a template engine and aliasing to .html files for ease of understanding.
This means we can even use EJS functionalities in HTML files */
app.engine("html", require("ejs").renderFile);

/* Serving Static files from folders */
app.use(express.static(__dirname + "/public"));
app.use(express.static("public/styles"));
app.use(express.static("views/UI"));
app.use(express.static("views/scripts"));

app.use(flash());
app.use(
  session({
    secret: "Secret Here",
    resave: true,
    saveUninitialized: true,
    cookie: { cookie: { maxAge: 600000000 } },
  })
);
app.use(passport.initialize());
app.use(passport.session());
app.use(methodOverride("_method"));

/* Route to render Quiz page */
app.get("/quiz", checkAuthenticated, (req, res) => {
  res.render("UI/quiz.html");
});

/* Route to render register page */
app.get("/register", checkNotAuthenticated, (req, res) => {
  res.render("register.html");
});

/* POST call to send the registration form data and save it into users table */
app.post("/register", checkNotAuthenticated, async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    users.push({
      username: req.body.username,
      email: req.body.email,
      password: hashedPassword,
    });
    db.run(
      DB_COMMANDS.REGISTER,
      [req.body.username, req.body.email, hashedPassword],
      (err, result) => {
        if (err) {
          res.redirect("/register");
          return;
        }
        res.redirect("/login");
      }
    );
  } catch {
    res.redirect("/register");
  }
});


/* Route to render login page */
app.get("/login", checkNotAuthenticated, (req, res) => {
  res.render("login.html");
});

app.post(
  "/login",
  checkNotAuthenticated,
  passport.authenticate("local", {
    successRedirect: "/",
    failureRedirect: "/login",
    failureFlash: true,
  })
);

/* To handle logout */
app.get("/logout", (req, res) => {
  req.session.destroy(function (err) {
    res.redirect("/login");
  });
});

/* To render Animals page */
app.get("/animals", checkAuthenticated, (req, res) => {
  res.render("UI/animals.html");
});

// API's

/* request format --> 

  {
    "animal_name":"Fox",
    "animal_desc":"Description about fox",
    "isEndangered":false
  }

*/
/* To render home page */
app.get("/", checkAuthenticated, (req, res) => {
  res.render("UI/welcome.html", { name: req.user.name });
});

/* Get all animals */
app.get("/api/animals", checkAuthenticated, (req, res) => {
  db.all(DB_COMMANDS.GET_ALL, [], (err, rows) => {
    if (err) {
      res.status(400).json({ error: err.message });
      return;
    }
    res.status(200).json({ rows });
  });
});

/* To render animal description page */
app.get("/animal", checkAuthenticated, (req, res) => {
  res.render("UI/animal-desc.html");
});

/* Retrieve the information about a specific animal */
app.get("/api/animals/:id", checkAuthenticated, (req, res) => {
  db.get(DB_COMMANDS.GET_BY_ID, [req.params.id], (err, row) => {
    if (err) {
      res.status(400).json({ error: err.message });
      return;
    }
    res.status(200).json(row);
  });
});

/* Create a new animal */
app.post("/api/animals/", (req, res, next) => {
  let reqBody = req.body;
  /*  checking if the animal already exists */
  db.get(DB_COMMANDS.GET_BY_NAME, [req.body.animal_name], (err, row) => {
    if (err) {
      res.status(400).json({ error: err.message });
      return;
    }
    if (row) {
      res
        .status(400)
        .send(
          "The Animal with name " + req.body.animal_name + " is already present in the database."
        );
    } else {
      db.run(
        DB_COMMANDS.CREATE_NEW,
        [reqBody.animal_name, reqBody.animal_desc, reqBody.isEndangered],
        (err, result) => {
          if (err) {
            res.status(400).json({ error: err.message });
            return;
          }
          res.status(201).json({
            animal_name: reqBody.animal_name,
          });
        }
      );
    }
  });
});

/* Update the detals of an animal using id */
app.put("/api/animals/:id", checkAuthenticated, (req, res) => {
  let reqBody = req.body;
  db.run(
    DB_COMMANDS.UPDATE,
    [reqBody.animal_name, reqBody.animal_desc, reqBody.isEndangered, req.params.id],
    (err, row) => {
      if (err) {
        res.status(400).json({ error: res.message });
        return;
      }
      res.status(201).json({ row });
    }
  );
});

/* Remove an animal by its ID */
app.delete("/api/animals/:id", checkAuthenticated, (req, res) => {
  db.run(DB_COMMANDS.DELETE, req.params.id, function (err, result) {
    if (err) {
      res.status(400).json({ error: res.message });
      return;
    }
    res.status(200).json({ deletedID: this.changes });
  });
});

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }

  res.redirect("/login");
}

function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect("/");
  }
  next();
}
